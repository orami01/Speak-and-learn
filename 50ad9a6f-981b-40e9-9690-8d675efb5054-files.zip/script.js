/**
 * Speak & Learn - Pronunciation Practice App for Children
 * 
 * This script provides the core functionality for a pronunciation practice web application
 * designed for children ages 5-9, including:
 * - Word/sentence display from a comprehensive vocabulary dataset
 * - Audio playback for pronunciation models
 * - Recording capabilities using the MediaRecorder API
 * - Speech recognition using the Web Speech API
 * - Basic feedback on pronunciation attempts
 */

// ===== APP STATE =====
// Main application state variables
const appState = {
    currentWordIndex: 0,       // Index of the current word in the vocabulary dataset
    mediaRecorder: null,       // MediaRecorder instance
    audioChunks: [],           // Array to store audio chunks during recording
    isRecording: false,        // Flag to track recording state
    audioBlob: null,           // Blob to store the complete recording
    audioUrl: null,            // URL for the audio blob (for playback)
    recognition: null,         // SpeechRecognition instance
    stream: null,              // MediaStream from getUserMedia
    speechRecognitionActive: false, // Flag to track if speech recognition is active
};

// ===== DOM ELEMENTS =====
// Cache DOM elements for performance
const elements = {
    currentWord: document.getElementById('current-word'),
    prevWordBtn: document.getElementById('prev-word'),
    nextWordBtn: document.getElementById('next-word'),
    playModelBtn: document.getElementById('play-model'),
    startRecordingBtn: document.getElementById('start-recording'),
    stopRecordingBtn: document.getElementById('stop-recording'),
    playbackRecordingBtn: document.getElementById('playback-recording'),
    speechResult: document.getElementById('speech-result'),
    feedbackMessage: document.getElementById('feedback-message'),
    permissionsOverlay: document.getElementById('permissions-overlay'),
    permissionsOkBtn: document.getElementById('permissions-ok'),
};

// ===== VOCABULARY DATASET =====
/**
 * Comprehensive dataset of beginner English words and simple phrases
 * for children ages 5-9 to practice pronunciation.
 * Each entry contains:
 * - text: The word or phrase to pronounce
 * - category: The category the word belongs to (colors, numbers, animals, etc.)
 * - level: Difficulty level (1: easiest, 3: more challenging)
 * 
 * Since we don't have actual audio files, the audio property is omitted.
 * In a real application, each entry would include an audio path.
 */
const vocabularyData = [
    // Basic Greetings and Phrases (Level 1)
    { text: "Hello", category: "greetings", level: 1 },
    { text: "Goodbye", category: "greetings", level: 1 },
    { text: "Thank you", category: "phrases", level: 1 },
    { text: "Please", category: "phrases", level: 1 },
    { text: "Yes", category: "phrases", level: 1 },
    { text: "No", category: "phrases", level: 1 },
    { text: "Sorry", category: "phrases", level: 1 },
    { text: "Excuse me", category: "phrases", level: 1 },
    { text: "My name is", category: "phrases", level: 1 },
    { text: "How are you", category: "phrases", level: 1 },
    
    // Colors (Level 1)
    { text: "Red", category: "colors", level: 1 },
    { text: "Blue", category: "colors", level: 1 },
    { text: "Green", category: "colors", level: 1 },
    { text: "Yellow", category: "colors", level: 1 },
    { text: "Orange", category: "colors", level: 1 },
    { text: "Purple", category: "colors", level: 1 },
    { text: "Pink", category: "colors", level: 1 },
    { text: "Brown", category: "colors", level: 1 },
    { text: "Black", category: "colors", level: 1 },
    { text: "White", category: "colors", level: 1 },
    
    // Numbers (Level 1)
    { text: "One", category: "numbers", level: 1 },
    { text: "Two", category: "numbers", level: 1 },
    { text: "Three", category: "numbers", level: 1 },
    { text: "Four", category: "numbers", level: 1 },
    { text: "Five", category: "numbers", level: 1 },
    { text: "Six", category: "numbers", level: 1 },
    { text: "Seven", category: "numbers", level: 1 },
    { text: "Eight", category: "numbers", level: 1 },
    { text: "Nine", category: "numbers", level: 1 },
    { text: "Ten", category: "numbers", level: 1 },
    
    // Animals (Level 1)
    { text: "Cat", category: "animals", level: 1 },
    { text: "Dog", category: "animals", level: 1 },
    { text: "Bird", category: "animals", level: 1 },
    { text: "Fish", category: "animals", level: 1 },
    { text: "Rabbit", category: "animals", level: 1 },
    { text: "Horse", category: "animals", level: 1 },
    { text: "Cow", category: "animals", level: 1 },
    { text: "Pig", category: "animals", level: 1 },
    { text: "Duck", category: "animals", level: 1 },
    { text: "Sheep", category: "animals", level: 1 },
    
    // Foods (Level 1)
    { text: "Apple", category: "foods", level: 1 },
    { text: "Banana", category: "foods", level: 1 },
    { text: "Orange", category: "foods", level: 1 },
    { text: "Milk", category: "foods", level: 1 },
    { text: "Bread", category: "foods", level: 1 },
    { text: "Water", category: "foods", level: 1 },
    { text: "Juice", category: "foods", level: 1 },
    { text: "Cookie", category: "foods", level: 1 },
    { text: "Pizza", category: "foods", level: 1 },
    { text: "Ice cream", category: "foods", level: 1 },
    
    // Family (Level 1)
    { text: "Mom", category: "family", level: 1 },
    { text: "Dad", category: "family", level: 1 },
    { text: "Brother", category: "family", level: 1 },
    { text: "Sister", category: "family", level: 1 },
    { text: "Baby", category: "family", level: 1 },
    { text: "Grandma", category: "family", level: 1 },
    { text: "Grandpa", category: "family", level: 1 },
    { text: "Family", category: "family", level: 1 },
    
    // Body Parts (Level 1)
    { text: "Head", category: "body", level: 1 },
    { text: "Eyes", category: "body", level: 1 },
    { text: "Nose", category: "body", level: 1 },
    { text: "Mouth", category: "body", level: 1 },
    { text: "Ears", category: "body", level: 1 },
    { text: "Hands", category: "body", level: 1 },
    { text: "Feet", category: "body", level: 1 },
    
    // School Items (Level 1)
    { text: "Book", category: "school", level: 1 },
    { text: "Pencil", category: "school", level: 1 },
    { text: "Paper", category: "school", level: 1 },
    { text: "Backpack", category: "school", level: 1 },
    { text: "Teacher", category: "school", level: 1 },
    { text: "Student", category: "school", level: 1 },
    
    // Simple Actions (Level 2)
    { text: "Jump", category: "actions", level: 2 },
    { text: "Run", category: "actions", level: 2 },
    { text: "Walk", category: "actions", level: 2 },
    { text: "Sit", category: "actions", level: 2 },
    { text: "Stand", category: "actions", level: 2 },
    { text: "Sleep", category: "actions", level: 2 },
    { text: "Eat", category: "actions", level: 2 },
    { text: "Drink", category: "actions", level: 2 },
    { text: "Play", category: "actions", level: 2 },
    { text: "Read", category: "actions", level: 2 },
    { text: "Write", category: "actions", level: 2 },
    { text: "Draw", category: "actions", level: 2 },
    
    // Simple Phrases (Level 2)
    { text: "I like apples", category: "phrases", level: 2 },
    { text: "The dog is big", category: "phrases", level: 2 },
    { text: "My cat is small", category: "phrases", level: 2 },
    { text: "Let's go outside", category: "phrases", level: 2 },
    { text: "Time for school", category: "phrases", level: 2 },
    { text: "Where is my book", category: "phrases", level: 2 },
    { text: "I can read", category: "phrases", level: 2 },
    { text: "Let's play a game", category: "phrases", level: 2 },
    
    // Weather (Level 2)
    { text: "Sunny", category: "weather", level: 2 },
    { text: "Rainy", category: "weather", level: 2 },
    { text: "Cloudy", category: "weather", level: 2 },
    { text: "Snowy", category: "weather", level: 2 },
    { text: "Windy", category: "weather", level: 2 },
    { text: "Hot", category: "weather", level: 2 },
    { text: "Cold", category: "weather", level: 2 },
    
    // Clothes (Level 2)
    { text: "Shirt", category: "clothes", level: 2 },
    { text: "Pants", category: "clothes", level: 2 },
    { text: "Socks", category: "clothes", level: 2 },
    { text: "Shoes", category: "clothes", level: 2 },
    { text: "Hat", category: "clothes", level: 2 },
    { text: "Jacket", category: "clothes", level: 2 },
    { text: "Sweater", category: "clothes", level: 2 },
    
    // More Complex Words (Level 3)
    { text: "Butterfly", category: "animals", level: 3 },
    { text: "Elephant", category: "animals", level: 3 },
    { text: "Dinosaur", category: "animals", level: 3 },
    { text: "Giraffe", category: "animals", level: 3 },
    { text: "Strawberry", category: "foods", level: 3 },
    { text: "Watermelon", category: "foods", level: 3 },
    { text: "Computer", category: "technology", level: 3 },
    { text: "Playground", category: "places", level: 3 },
    { text: "Hospital", category: "places", level: 3 },
    { text: "Restaurant", category: "places", level: 3 },
    
    // Complex Phrases (Level 3)
    { text: "My favorite color is blue", category: "phrases", level: 3 },
    { text: "I want to go to the park", category: "phrases", level: 3 },
    { text: "The cat is sleeping on the bed", category: "phrases", level: 3 },
    { text: "Please pass me the pencil", category: "phrases", level: 3 },
    { text: "Today is a beautiful day", category: "phrases", level: 3 },
    { text: "I like to read books", category: "phrases", level: 3 },
    { text: "Can you help me please", category: "phrases", level: 3 },
    { text: "I want to play with my friends", category: "phrases", level: 3 },
    { text: "It's time to go to school", category: "phrases", level: 3 },
    { text: "What time is it", category: "phrases", level: 3 }
];

// ===== CORE FUNCTIONS =====

/**
 * Initialize the application when the page loads
 */
function initApp() {
    // Display the first word
    displayCurrentWord();
    
    // Initialize the speech recognition
    initSpeechRecognition();
    
    // Event listener for permissions overlay
    elements.permissionsOkBtn.addEventListener('click', () => {
        elements.permissionsOverlay.classList.add('hidden');
    });
    
    // Show permissions overlay on first load
    // In a production app, this would be shown only on first visit
    // For demo purposes, we'll show it every time
    setTimeout(() => {
        elements.permissionsOverlay.classList.remove('hidden');
    }, 1000);

    // Feature detection for required APIs
    checkBrowserSupport();
}

/**
 * Check browser support for required APIs
 * Added for better browser compatibility detection
 */
function checkBrowserSupport() {
    let warningMessages = [];
    
    // Check for SpeechRecognition
    if (!('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
        warningMessages.push("Speech recognition is not supported in your browser. Please try Chrome, Edge, or Safari.");
        elements.startRecordingBtn.disabled = true;
    }
    
    // Check for MediaRecorder
    if (!('MediaRecorder' in window)) {
        warningMessages.push("Audio recording is not supported in your browser. Please try a modern browser like Chrome, Firefox, Edge, or Safari.");
        elements.startRecordingBtn.disabled = true;
        elements.stopRecordingBtn.disabled = true;
    }
    
    // Check for SpeechSynthesis
    if (!('speechSynthesis' in window)) {
        warningMessages.push("Text-to-speech is not supported in your browser. You won't be able to hear the correct pronunciation.");
        elements.playModelBtn.disabled = true;
    }
    
    // Display warnings if any
    if (warningMessages.length > 0) {
        const message = warningMessages.join(" ");
        showError(message);
    }
}

/**
 * Display the current word from the vocabulary dataset
 */
function displayCurrentWord() {
    const currentWord = vocabularyData[appState.currentWordIndex];
    elements.currentWord.textContent = currentWord.text;
    
    // Reset the speech result and feedback message
    elements.speechResult.innerHTML = `<p class="placeholder">Your words will appear here after you speak</p>`;
    elements.feedbackMessage.textContent = '';
    elements.feedbackMessage.className = 'feedback-message';
    
    // Reset recording state
    if (appState.audioUrl) {
        URL.revokeObjectURL(appState.audioUrl);
        appState.audioUrl = null;
        appState.audioBlob = null;
    }
    elements.playbackRecordingBtn.disabled = true;
}

/**
 * Navigate to the previous word in the vocabulary dataset
 */
function previousWord() {
    if (appState.currentWordIndex > 0) {
        appState.currentWordIndex--;
        displayCurrentWord();
    }
}

/**
 * Navigate to the next word in the vocabulary dataset
 */
function nextWord() {
    if (appState.currentWordIndex < vocabularyData.length - 1) {
        appState.currentWordIndex++;
        displayCurrentWord();
    }
}

/**
 * Play the model audio for the current word
 * Note: In a real application, this would play an actual audio file.
 * For this demo, we're using Web Speech API's speech synthesis
 */
function playModelAudio() {
    try {
        const currentWord = vocabularyData[appState.currentWordIndex];
        
        // Cancel any previous speech synthesis
        window.speechSynthesis.cancel();
        
        // Create an utterance using the Web Speech API
        const utterance = new SpeechSynthesisUtterance(currentWord.text);
        
        // Adjust voice parameters to be kid-friendly
        utterance.rate = 0.8; // Slightly slower than normal
        utterance.pitch = 1.2; // Slightly higher pitch
        
        // Try to use a female voice if available (often clearer for language learning)
        const voices = window.speechSynthesis.getVoices();
        const englishVoices = voices.filter(voice => voice.lang.includes('en-'));
        
        if (englishVoices.length > 0) {
            // Prefer female voices if available
            const femaleVoices = englishVoices.filter(voice => voice.name.includes('Female') || voice.name.includes('female'));
            if (femaleVoices.length > 0) {
                utterance.voice = femaleVoices[0];
            } else {
                utterance.voice = englishVoices[0];
            }
        }
        
        // Event handlers for speech synthesis
        utterance.onstart = () => {
            // Provide visual feedback that the audio is playing
            elements.playModelBtn.classList.add('active');
        };
        
        utterance.onend = () => {
            // Remove the active class when audio ends
            elements.playModelBtn.classList.remove('active');
        };
        
        utterance.onerror = (event) => {
            console.error("Speech synthesis error:", event);
            elements.playModelBtn.classList.remove('active');
            showError("There was a problem playing the audio. Please try again.");
        };
        
        // Play the audio
        window.speechSynthesis.speak(utterance);
    } catch (error) {
        console.error("Error in playModelAudio:", error);
        showError("There was a problem playing the audio. Please try again.");
        elements.playModelBtn.classList.remove('active');
    }
}

/**
 * Initialize the speech recognition object
 */
function initSpeechRecognition() {
    // Check for browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
        console.error("Speech recognition not supported");
        return;
    }
    
    // Create a speech recognition instance
    appState.recognition = new SpeechRecognition();
    
    // Configure the recognition
    appState.recognition.continuous = false;
    appState.recognition.interimResults = false;
    appState.recognition.lang = 'en-US';
    appState.recognition.maxAlternatives = 3; // Get multiple alternatives for better matching
    
    // Set up event handlers
    appState.recognition.onresult = handleSpeechResult;
    appState.recognition.onerror = handleSpeechError;
    appState.recognition.onend = handleSpeechEnd;
}

/**
 * Start the speech recognition process
 */
function startSpeechRecognition() {
    try {
        // If recognition is already active, abort it first
        if (appState.speechRecognitionActive) {
            appState.recognition.abort();
        }
        
        appState.recognition.start();
        appState.speechRecognitionActive = true;
    } catch (error) {
        console.error("Speech recognition error:", error);
        appState.speechRecognitionActive = false;
        showError("There was a problem with speech recognition. Please try again.");
    }
}

/**
 * Handle the result from speech recognition
 */
function handleSpeechResult(event) {
    appState.speechRecognitionActive = false;
    
    try {
        const currentWord = vocabularyData[appState.currentWordIndex].text.toLowerCase();
        
        // Get the best match from the results
        let speechResult = "";
        if (event.results && event.results.length > 0 && event.results[0].length > 0) {
            speechResult = event.results[0][0].transcript.toLowerCase();
        } else {
            throw new Error("No speech results detected");
        }
        
        // Display the recognized speech
        elements.speechResult.innerHTML = `<p>${speechResult}</p>`;
        
        // Simple comparison to check if the pronunciation is close enough
        compareAndGiveFeedback(currentWord, speechResult);
    } catch (error) {
        console.error("Error processing speech results:", error);
        elements.speechResult.innerHTML = `<p class="error">Sorry, I couldn't understand that. Please try again.</p>`;
    }
}

/**
 * Compare the recognized speech with the target word and provide feedback
 */
function compareAndGiveFeedback(targetWord, spokenWord) {
    // For a simple approach, we'll check if the words are similar
    // In a real app, you'd use a more sophisticated algorithm or API
    
    // Convert both to lowercase for comparison
    targetWord = targetWord.toLowerCase();
    spokenWord = spokenWord.toLowerCase();
    
    // Calculate similarity (very basic)
    // This is a simplified approach - a real app would use more sophisticated methods
    const similarity = calculateSimilarity(targetWord, spokenWord);
    
    // Provide feedback based on similarity
    if (similarity > 0.8) {
        // Great job
        elements.feedbackMessage.textContent = "Great job! 🌟";
        elements.feedbackMessage.className = 'feedback-message feedback-success';
    } else if (similarity > 0.6) {
        // Good try
        elements.feedbackMessage.textContent = "Good try! Let's practice again. 😊";
        elements.feedbackMessage.className = 'feedback-message';
    } else {
        // Needs more practice
        elements.feedbackMessage.textContent = "Keep practicing! Try again. 💪";
        elements.feedbackMessage.className = 'feedback-message feedback-error';
    }
}

/**
 * Calculate a simple similarity score between two strings
 * This is a very basic implementation of the Levenshtein distance algorithm
 */
function calculateSimilarity(str1, str2) {
    // Special case for empty strings
    if (str1.length === 0 && str2.length === 0) return 1.0;
    if (str1.length === 0 || str2.length === 0) return 0.0;
    
    // Calculate Levenshtein distance
    const distance = levenshteinDistance(str1, str2);
    
    // Convert to similarity score (0 to 1)
    const maxLength = Math.max(str1.length, str2.length);
    
    return 1.0 - (distance / maxLength);
}

/**
 * Calculate the Levenshtein distance between two strings
 * This measures how many edits are needed to transform one string into another
 */
function levenshteinDistance(str1, str2) {
    // Handle edge cases
    if (str1 === str2) return 0;
    if (str1.length === 0) return str2.length;
    if (str2.length === 0) return str1.length;
    
    const m = str1.length;
    const n = str2.length;
    
    // Create a matrix of size (m+1) x (n+1)
    const dp = Array(m + 1).fill().map(() => Array(n + 1).fill(0));
    
    // Initialize the matrix
    for (let i = 0; i <= m; i++) {
        dp[i][0] = i;
    }
    for (let j = 0; j <= n; j++) {
        dp[0][j] = j;
    }
    
    // Fill the matrix
    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            if (str1[i - 1] === str2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1]; // No edit needed
            } else {
                dp[i][j] = 1 + Math.min(
                    dp[i - 1][j],     // Deletion
                    dp[i][j - 1],     // Insertion
                    dp[i - 1][j - 1]  // Substitution
                );
            }
        }
    }
    
    // Return the distance
    return dp[m][n];
}

/**
 * Handle speech recognition errors
 */
function handleSpeechError(event) {
    appState.speechRecognitionActive = false;
    console.error("Speech recognition error:", event.error);
    
    let errorMessage = "There was a problem with speech recognition. ";
    
    // Custom error messages based on the type of error
    switch (event.error) {
        case 'no-speech':
            errorMessage += "No speech was detected. Please try again and speak clearly.";
            break;
        case 'audio-capture':
            errorMessage += "No microphone was found or microphone is not working.";
            break;
        case 'not-allowed':
            errorMessage += "Microphone permission was denied. Please allow microphone access.";
            elements.permissionsOverlay.classList.remove('hidden');
            break;
        case 'network':
            errorMessage += "A network error occurred. Please check your internet connection.";
            break;
        case 'aborted':
            // This is an expected error when we manually abort, don't show error
            return;
        default:
            errorMessage += "Please try again.";
    }
    
    showError(errorMessage);
}

/**
 * Handle speech recognition ending
 */
function handleSpeechEnd() {
    // Reset the flag
    appState.speechRecognitionActive = false;
    
    // If we were recording but didn't get any results, show an error
    if (appState.isRecording && elements.speechResult.innerHTML.includes('placeholder')) {
        elements.speechResult.innerHTML = `<p class="error">I didn't hear anything. Please try again.</p>`;
    }
}

/**
 * Start recording audio using the MediaRecorder API
 */
function startRecording() {
    // First, ensure previous recordings are cleaned up
    if (appState.mediaRecorder && appState.isRecording) {
        stopRecording();
        return; // Exit early to prevent double-starting
    }
    
    // Reset audio chunks array
    appState.audioChunks = [];
    
    // Clear any previous results
    elements.speechResult.innerHTML = `<p class="placeholder">Your words will appear here after you speak</p>`;
    elements.feedbackMessage.textContent = '';
    elements.feedbackMessage.className = 'feedback-message';
    
    // Request access to the microphone
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            appState.stream = stream;
            
            // Create a new MediaRecorder instance
            appState.mediaRecorder = new MediaRecorder(stream);
            
            // Set up event handlers for the MediaRecorder
            appState.mediaRecorder.ondataavailable = event => {
                if (event.data.size > 0) {
                    appState.audioChunks.push(event.data);
                }
            };
            
            appState.mediaRecorder.onstop = processRecording;
            
            appState.mediaRecorder.onerror = (event) => {
                console.error("MediaRecorder error:", event);
                showError("There was a problem with recording. Please try again.");
                stopRecording();
            };
            
            // Start recording
            appState.mediaRecorder.start();
            appState.isRecording = true;
            
            // Update UI
            elements.startRecordingBtn.disabled = true;
            elements.stopRecordingBtn.disabled = false;
            
            // Also start speech recognition when we start recording
            startSpeechRecognition();
            
        })
        .catch(error => {
            console.error("Error accessing microphone:", error);
            
            let errorMessage = "Could not access your microphone. ";
            
            // Provide more specific error messages
            if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
                errorMessage += "Microphone permission was denied. Please allow microphone access.";
                elements.permissionsOverlay.classList.remove('hidden');
            } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
                errorMessage += "No microphone was found. Please connect a microphone and try again.";
            } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
                errorMessage += "Your microphone is busy or not working properly.";
            } else {
                errorMessage += "Please check your settings and try again.";
            }
            
            showError(errorMessage);
        });
}

/**
 * Stop recording audio
 */
function stopRecording() {
    try {
        if (appState.mediaRecorder && appState.isRecording) {
            // Stop the MediaRecorder
            appState.mediaRecorder.stop();
            appState.isRecording = false;
            
            // Stop all tracks in the stream to release the microphone
            if (appState.stream) {
                appState.stream.getTracks().forEach(track => track.stop());
                appState.stream = null;
            }
            
            // Stop speech recognition if it's still active
            if (appState.speechRecognitionActive) {
                try {
                    appState.recognition.abort();
                } catch (e) {
                    console.error("Error stopping speech recognition:", e);
                }
                appState.speechRecognitionActive = false;
            }
            
            // Update UI
            elements.startRecordingBtn.disabled = false;
            elements.stopRecordingBtn.disabled = true;
        }
    } catch (error) {
        console.error("Error in stopRecording:", error);
        
        // Reset state and UI in case of error
        appState.isRecording = false;
        elements.startRecordingBtn.disabled = false;
        elements.stopRecordingBtn.disabled = true;
        
        // Clean up stream if it exists
        if (appState.stream) {
            try {
                appState.stream.getTracks().forEach(track => track.stop());
            } catch (e) {
                console.error("Error stopping tracks:", e);
            }
            appState.stream = null;
        }
    }
}

/**
 * Process the recording after it stops
 */
function processRecording() {
    try {
        // Create a Blob from the audio chunks
        if (appState.audioChunks.length === 0) {
            console.warn("No audio chunks recorded");
            return;
        }
        
        const audioType = 'audio/webm';
        appState.audioBlob = new Blob(appState.audioChunks, { type: audioType });
        
        // Check if we have a valid blob
        if (appState.audioBlob.size === 0) {
            console.warn("Empty audio blob created");
            return;
        }
        
        // Create a URL for the Blob
        appState.audioUrl = URL.createObjectURL(appState.audioBlob);
        
        // Enable the playback button
        elements.playbackRecordingBtn.disabled = false;
    } catch (error) {
        console.error("Error processing recording:", error);
        showError("There was a problem processing your recording. Please try again.");
    }
}

/**
 * Play back the recorded audio
 */
function playbackRecording() {
    if (!appState.audioUrl) {
        showError("No recording available to play. Please record first.");
        return;
    }
    
    try {
        // Create a temporary audio element
        const audio = new Audio(appState.audioUrl);
        
        // Add event listeners
        audio.onplay = () => {
            // Provide visual feedback that the audio is playing
            elements.playbackRecordingBtn.classList.add('active');
        };
        
        audio.onended = () => {
            // Remove the active class when audio ends
            elements.playbackRecordingBtn.classList.remove('active');
        };
        
        audio.onerror = (error) => {
            console.error("Error playing audio:", error);
            elements.playbackRecordingBtn.classList.remove('active');
            showError("Could not play your recording. Please try again.");
        };
        
        // Play the audio
        const playPromise = audio.play();
        
        // Handle play promise rejection (autoplay policy in some browsers)
        if (playPromise !== undefined) {
            playPromise.catch(error => {
                console.error("Play promise rejected:", error);
                elements.playbackRecordingBtn.classList.remove('active');
                showError("Could not play your recording. Please try again.");
            });
        }
    } catch (error) {
        console.error("Error in playbackRecording:", error);
        showError("Could not play your recording. Please try again.");
    }
}

/**
 * Display an error message
 */
function showError(message) {
    elements.feedbackMessage.textContent = message;
    elements.feedbackMessage.className = 'feedback-message feedback-error';
}

// ===== EVENT LISTENERS =====
// Set up event listeners when the page loads
window.addEventListener('DOMContentLoaded', () => {
    // Navigation buttons
    elements.prevWordBtn.addEventListener('click', previousWord);
    elements.nextWordBtn.addEventListener('click', nextWord);
    
    // Audio controls
    elements.playModelBtn.addEventListener('click', playModelAudio);
    elements.startRecordingBtn.addEventListener('click', startRecording);
    elements.stopRecordingBtn.addEventListener('click', stopRecording);
    elements.playbackRecordingBtn.addEventListener('click', playbackRecording);
    
    // Initialize the voices for speech synthesis
    if (window.speechSynthesis) {
        // Load voices when available
        const loadVoices = () => {
            // Force load voices
            window.speechSynthesis.getVoices();
        };
        
        // Some browsers need this event
        if (speechSynthesis.onvoiceschanged !== undefined) {
            speechSynthesis.onvoiceschanged = loadVoices;
        }
        
        // Try to load voices immediately as well
        loadVoices();
    }
    
    // Initialize the app
    initApp();
});